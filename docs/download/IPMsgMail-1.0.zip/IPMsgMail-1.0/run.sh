java -jar IPMsgMail-1.0.jar
