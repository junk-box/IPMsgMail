----------------------------------------------------------------------
IPMsgMail
http://junk-box.appspot.com/software/ipmsgmail/index.html
Copyright (C) 2012 S.Ishigaki All Rights Reserved.
----------------------------------------------------------------------

【概要】
PMsgMailはIP Messengerにログ閲覧機能を合体したメーラーライクなメッセンジャーです。

IPMsgMailの特徴
    ◇IPMessger Ver2 プロトコル互換
        ・メッセージ送受信
        ・メッセージ暗号化
        ・封書
        ・ファイル送受信
    ◇IPMessengerで出力したログをインポート可能
        IPMessengerからのスムーズな移行が可能です。
    ◇メッセージの高速検索

IPMsgMailはフリーウェアです。無償で利用できます。


【動作環境】
Java Runtime Environment Version 6 以上 (Windows環境推奨)

Javaは下記サイトよりインストールして下さい。
http://java.com/ja/

Linuxでも動作しますが、挙動があやしい＆デザインが崩れることがあります。
サポート対象はWindows環境のみとします。


【インストール】
解凍し、任意のディレクトリに配置して下さい。


【起動】
IPMsgMail-1.0.jar をダブルクリックで起動します。

起動しない場合、以下のコマンドを実行してください。
java -jar IPMsgMail-1.0.jar
  ※起動用シェル(run.bat, run.sh)を同梱してあります。


【アンインストール】
ディレクトリを削除して下さい。


【免責事項】
本ソフトウェアの使用により生じたいかなる問題に対して作者は一切の責任を負いません。
本ソフトウェアに不具合が発見された場合、バージョンアップの義務を負わないものとします。


【転載・再配布】
本ソフトウェアの改造・転載・再配布に制限はありません。


【商用利用】
本ソフトウェアの商用利用に制限はありません。


【不具合報告・要望】
IPMsgMailの不具合報告・要望はこちらからどうぞ
http://junk-box.appspot.com/software/ipmsgmail/support.html

