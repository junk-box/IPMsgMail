java -jar IPMsgMail-1.1.jar
